export const navigation = ['Home', 'Work', 'Services', 'About', 'Experience', 'Skills', 'Contact'];
export const socials = [
 {name:'YouTube',handle:'@navrixa',url:'https://youtube.com/@navrixa'},
 {name:'TikTok',handle:'NAVRIXA',url:'https://www.tiktok.com/search?q=navrixa&t=1788962572510'},
 // Replace these profile URLs whenever the handles change.
 {name:'Instagram',handle:'@navrixa.mv',url:'https://www.instagram.com/navrixa.mv/'},
 {name:'Creative Portfolio',handle:'@navrixa.visual',url:'https://www.instagram.com/navrixa.visual/'},
];
// Add verified profile URLs to enable these links in the contact section.
export const additionalSocials = [{name:'GitHub',url:''},{name:'LinkedIn',url:''}];
export const projects = [
 {id:'cinematic',number:'01',title:'The art of being somewhere.',category:'Cinematic & Drone Production',client:'NAVRIXA · Destination storytelling',image:'/images/hammad-filming.webp',className:'work-large',description:'Destination videos, cinematic filming, drone footage, tourism visuals, travel stories and promotional productions.',outcome:'Created immersive visual experiences designed for digital platforms, tourism campaigns and promotional communication.',tags:['Cinematic filming','Tourism','Drone footage']},
 {id:'broadcast',number:'02',title:'Stories that reach a nation.',category:'Broadcast & Television',client:'PSM · NTV Maldives · Sun Media · MTV Maldives',image:'/images/hammad-camera.webp',className:'work-tall',description:'News, television programmes, documentaries and broadcast content for Maldivian audiences.',outcome:'Delivered deadline-driven television and digital content while maintaining professional broadcast production standards.',tags:['Broadcast','Documentary','Video editing']},
 {id:'corporate',number:'03',title:'A bigger picture. A clearer message.',category:'Corporate Media',client:'Maldives Airports Company Ltd',image:'/images/hammad-camera.webp',className:'work-wide',description:'Corporate communication, promotional content, airport operations, events and internal media production.',outcome:'Produced polished visual stories supporting internal communication, corporate branding and external communication.',tags:['Corporate communication','Events','Aviation']},
 {id:'digital',number:'04',title:'Built to connect.',category:'Social Media & Digital Campaigns',client:'Content · Campaigns · Digital strategy',image:'/images/navrixa-brand.webp',className:'',description:'Social media content, marketing campaigns, captions, promotional communication and digital strategy.',outcome:'Strengthened digital brand presence through strategic multimedia content and audience-focused campaigns.',tags:['Content strategy','Social media','Marketing']},
 {id:'communication',number:'05',title:'Complex information. Clear stories.',category:'Creative Data & Corporate Communication',client:'Reporting · Learning · Communication',image:'/images/navrixa-brand.webp',className:'work-large',description:'Corporate presentations, visual reports, dashboards, infographics and communication materials.',outcome:'Transformed operational, training and organisational information into clear and engaging visual communication.',tags:['Visual reports','Presentations','Infographics']},
];
export const services = [
 ['Marketing Strategy Consulting','Develop practical content and marketing strategies aligned with business objectives, audiences and digital platforms.'],
 ['Social Media Content Creation','Engaging social media videos, photography, captions, campaign concepts and platform-focused content.'],
 ['Video Production','Professional concept development, filming, editing and delivery for corporate, tourism, social media and promotional projects.'],
 ['Video Editing','Cinematic editing, colour grading, sound design, motion graphics and digital platform optimisation.'],
 ['Digital Marketing','Content marketing, campaign planning, audience growth, performance reporting and brand communication.'],
 ['Corporate Media','Corporate videos, internal communication, events, presentations, training media and organisational storytelling.'],
 ['Tourism & Destination Content','Cinematic destination videos, travel content, drone visuals, resort content and Maldives-focused storytelling.'],
 ['Creative Direction','Campaign concepts, visual identity guidance, content planning and multimedia storytelling.'],
];
export const experience = [
 {role:'Executive — Learning & Development',company:'Maldives Airports Company Ltd',date:'2025 — Present',description:'Support organisational learning, communication, reporting and creative visual information.'},
 {role:'Videographer & Video Editor — PR & Communication',company:'Maldives Airports Company Ltd',date:'2024 — 2025',description:'Produced corporate, promotional, operational and event-focused multimedia content.'},
 {role:'Content Creator Consultant — Social Media Group',company:'Spectrum Icontek International Corporation',location:'Quezon City, Philippines',description:'Created multimedia, social media and communication content supporting digital engagement.'},
 {role:'Freelance Video Editor',company:'NTV Maldives',description:'Produced broadcast-ready television and digital video content.'},
 {role:'Social Media Executive',company:'Code2Lab',description:'Supported content strategy, digital campaigns and social media communication.'},
 {role:'Video Editor & Videographer',company:'Public Service Media — PSM',description:'Produced television, news and multimedia content for broadcast audiences.'},
 {role:'Videographer',company:'Sun Media / Sun.MV',description:'Created video and digital news content for online audiences.'},
 {role:'Video Editor & Videographer',company:'MTV Maldives — Islamic Channel',description:'Produced broadcast programmes and multimedia content.'},
];
export const skillGroups = [
 {title:'Video & Production',items:['Adobe Premiere Pro','Adobe After Effects','DaVinci Resolve','Camera Operation','Cinematic Filming','Colour Grading','Sound Design','Motion Graphics','Drone Footage']},
 {title:'Creative',items:['Adobe Photoshop','Visual Storytelling','Photography','Brand Content','Creative Direction','Multimedia Production']},
 {title:'Digital Marketing',items:['Content Marketing','Marketing Strategy','Campaign Planning','Social Media Management','Brand Communication','SEO','Performance Analytics','Audience Growth','Content Strategy']},
];
export const education = [
 {title:'Bachelor of Information Technology',school:'Maldives Business School',status:'In progress'},
 {title:'Associate Degree in Information Technology',school:'',status:''},
 {title:'Diploma in Information Technology',school:'',status:''},
 {title:'Bachelor of Graphics & Multimedia',school:'',status:'In progress'},
 {title:'Level 5 Diploma in Business Management',school:'',status:''},
];
export const development = ['Digital Marketing','SEO','Cinematography','TV Camera Operation','Promotional Video Production','Tourism','Event Operations','Creative Media Production'];
export const marquee = ['Visual Storytelling','Video Production','Cinematic Filming','Video Editing','Digital Marketing','Social Media','Motion Graphics','Drone Footage','Brand Content','Color Grading','Photography','Content Strategy','Creative Direction','Marketing Strategy'];
export const projectTypes = ['Marketing Strategy','Social Media Content','Video Production','Video Editing','Corporate Media','Tourism Content','Digital Campaign','Creative Collaboration','Other'];

import {VideoGallery,PhotoGallery} from '@/components/portfolio/media-gallery';
import {Navbar,Hero,SkillsMarquee,FeaturedWork,Services,About,ExperienceTimeline,Skills,Education,NavrixaBrand,Contact,Footer} from '@/components/portfolio/site';
export default function Home(){return <><a className="skip-link" href="#main">Skip to content</a><Navbar/><main id="main"><Hero/><SkillsMarquee/><VideoGallery/><PhotoGallery/><FeaturedWork/><Services/><About/><ExperienceTimeline/><Skills/><Education/><NavrixaBrand/><Contact/></main><Footer/></>}
